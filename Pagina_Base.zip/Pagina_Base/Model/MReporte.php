<?php
include("../Config/conexion.php");
include("../View/VPlantilla.php");
$sql = "SELECT * from datos";
$resultado = mysqli_query($conexion, $sql);

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(10, 10, 'ID', 1, 0, 'C');
$pdf->Cell(30, 10, 'Nombre', 1, 0, 'C');
$pdf->Cell(30, 10, 'Apellido', 1, 0, 'C');
$pdf->Cell(30, 10, 'Clave', 1, 0, 'C');

$pdf-> Ln();

while($mostar = mysqli_fetch_array($resultado))
{
    $pdf->Cell(10, 10, $mostar['id'], 1, 0, 'C');
    $pdf->Cell(30, 10, $mostar['nombre'], 1, 0, 'C');
    $pdf->Cell(30, 10, $mostar['apellido'], 1, 0, 'C');
    $pdf->Cell(30, 10, $mostar['clave'], 1, 0, 'C');  
    $pdf-> Ln();
}
$pdf->Output('I');
?>