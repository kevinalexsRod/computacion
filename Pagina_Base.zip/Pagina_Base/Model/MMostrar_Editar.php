<?php 
    include("../Config/conexion.php");
    $id=$_REQUEST['id'];
    $sql = "SELECT * from datos where id = $id";
    $resultado = mysqli_query($conexion, $sql);

    while($mostrar = mysqli_fetch_array($resultado))
    {
?>
    
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
</head>
<body>
    <form action="../Model/MActualizar.php" method="post">
    <input type="hidden" name="id" value="<?php echo $mostrar['id']; ?>">
    <label for="">Nombre: </label>
    <input type="text" name="nombre" id="" value=<?php echo $mostrar['nombre'];?> placeholder="Nombre">
    <br>
    <label for="">Apellido: </label>
    <input type="text" name="apellido" value=<?php echo $mostrar['apellido'];?> placeholder="Apellido">
    <br>
    <label for="">Clave: </label>
    <input type="text" name="clave" value=<?php echo $mostrar['clave'];?> id="">
    <br>
    <br>
    <?php

}
?>
    <input type="submit" value="Guardar datos" name="editar">
    </form>

</body>


</html>

