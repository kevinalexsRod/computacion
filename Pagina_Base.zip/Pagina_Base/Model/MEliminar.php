<?php
    include("../Config/conexion.php");
    $idE = $_REQUEST['id'];
    $sql = "DELETE from datos where id= $idE";
    $resultado = mysqli_query($conexion, $sql);
    if($resultado)
    header("location:../Index.html");
else
echo "No se eliminó";
?>