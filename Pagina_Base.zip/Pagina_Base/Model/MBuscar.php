<?php
include("../Config/conexion.php");
$id = $_POST['id'];

$sql = "SELECT * from datos where id='$id'";
$resultado = mysqli_query($conexion, $sql);
include("../View/VTabla.php");
while($mostar = mysqli_fetch_array($resultado))
{
?>
    <tr>
        <td> <?php echo $mostar['id']; ?> </td>
        <td> <?php echo $mostar['nombre']; ?> </td>
        <td> <?php echo $mostar['apellido']; ?> </td>
        <td> <?php echo $mostar['clave']; ?> </td>
    </tr>
<?php
}
?>