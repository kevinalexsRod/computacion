<?php
include("../Config/conexion.php");
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $clave = sha1($_POST['clave']);

    $sql = "UPDATE datos SET nombre = '$nombre', apellido = '$apellido', clave = '$clave' WHERE id = $id";
    $resultado = mysqli_query($conexion, $sql);

    if ($resultado) {
        header("location:../Index.html");
    } else {
        echo "Error al actualizar los datos: ";
    }
?>
