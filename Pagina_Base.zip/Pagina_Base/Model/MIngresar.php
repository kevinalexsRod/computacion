<?php
include("../Config/conexion.php");
$nombre= $_POST['nombre'];
$apellido= $_POST['apellido'];
$clave= sha1($_POST['clave']);


$sql = "INSERT INTO datos(nombre, apellido, clave) VALUES ('$nombre', '$apellido', '$clave')";
$resultado = mysqli_query($conexion, $sql);

if($resultado)
    header("location:../Index.html");
else
echo "No se insertó";
?>