<?php
include("../Config/conexion.php");
$id = $_POST['id'];
$nombre= $_POST['nombre'];
$apellido= $_POST['apellido'];
$clave= sha1($_POST['clave']);

$sql = "UPDATE datos SET nombre = $nombre; WHERE id = $id;";
$sql = "UPDATE datos SET apellido = $apellido; WHERE id = $id;";
$sql = "UPDATE datos SET clave = $clave; WHERE id = $id;";
$resultado = mysqli_query($conexion, $sql);
if($resultado)
header("location:../View/VIngresar.php");
else
echo "No se eliminó";
?>

