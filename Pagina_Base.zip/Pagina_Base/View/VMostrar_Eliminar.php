<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminiar</title>
</head>
<body>
    <center><h1>Datos del usuario</h1></center>
    <center><table border="1" ></center>
    <td>ID</td>
    <td>Nombre</td>
    <td>Apellido</td>
    <td>Clave</td>

    <?php
    include("../Model/MMostrar_Eliminar.php");
    ?>
    </table>
</body>
</html>