<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tlaba</title>
</head>

<body>
    <center>
        <h1>Datosa del Usuario</h1>
    </center>
    <center>
        <table border="1">
    </center>
    <tr>
    <td>ID</td>
    <td>Nombre</td>
    <td>Apellido</td>
    <td>Clave</td>
    </tr>
    </table>
</body>

</html>