<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingreso de datos</title>
</head>
<body>
    <h1>Ingreso de datos</h1>
    <form action="../Model/MIngresar.php" method="post">
    <label for="">Nombre: </label>
    <input type="text" name="nombre" id="" placeholder="Nombre">
    <br>
    <label for="">Apellido: </label>
    <input type="text" name="apellido" id="" placeholder="Apellido">
    <br>
    <label for="">Clave: </label>
    <input type="text" name="clave" id="">
    <br>
    <br>
    <input type="submit" value="Guardar datos" name="ingresar">
    </form>
</body>
</html>