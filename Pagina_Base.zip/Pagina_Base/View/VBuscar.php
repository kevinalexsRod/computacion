<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar</title>
</head>
<body>
    <h1>Buscar</h1>
    <form action="../Model/MBuscar.php" method="post">
        <label for="">Ingrese el ID del usuario a buscar: </label>
        <input type="text" name="id" id="" placeholder="id">
        <br>
        <input type="submit" value="Buscar" name="buscar">
    </form>
</body>
</html>