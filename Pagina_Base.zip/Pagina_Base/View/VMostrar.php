<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos del usuario</title>

</head>
<body>
 
    <center><h1>DATOS DEL ESTUDIANTES</h1></center>
    <center> <table border="1"> </center>
    <td>ID</td>
    <td>NOMBRE</td>
    <td>APELLIDO</td>
    <td>CLAVE</td>
    <?php  include("../Model/MMostrarD.php"); ?> 
    </table>
    
</body>
</html>