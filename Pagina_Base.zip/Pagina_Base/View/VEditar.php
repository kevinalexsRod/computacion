<?php
include("../Config/conexion.php");
$idE= $_REQUEST['id'];
$sql = "SELECT * from datos where id= $idE";

$resultado = mysqli_query($conexion, $sql);

while($mostar = mysqli_fetch_array($resultado))
{
?>
    <h1>Editar datos</h1>
    <form action="../Model/MEditar.php" method="post">
        <label for="">Id: <?php echo $mostar['id']; ?></label><br><br>
        <label for="">Nombre:</label>
        <input type="text" name="nombre" id="" placeholder="<?php echo $mostar['nombre']; ?>"> <br><br>
        <label for="">Apellido:</label>
        <input type="text" name="nombre" id="" placeholder="<?php echo $mostar['apellido']; ?>"> <br><br>
        <label for="">Clave:</label>
        <input type="text" name="nombre" id="" placeholder="<?php echo $mostar['clave']; ?>"> <br><br>
        <input type="submit" value="Guardar datos" name="ingresar">
    </form>
<?php

}
?>

    
    