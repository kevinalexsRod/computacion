<?php
$var1 = $_GET['dato1'];
if($var1 == 1)
{
    include("../View/VIngresar.php");
}
else
if($var1 == 2)
{
    include("../View/VMostrar.php");
}
else
if($var1 == 3)
{
    include("../View/VBuscar.php");
}
if($var1 == 4)
{
    include("../View/VMostrar_Eliminar.php");
}
else
if($var1 == 5)
{
    include("../Model/MReporte.php");
}
?>